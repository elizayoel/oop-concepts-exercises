package Les_Oct25_Assignment_Users;

public class Admin extends User{
    public Admin(){
        super();
    }
    public Admin (String user_id,String password, String name, String address, String phone_num, String email_add){
        super(user_id,password,name,address,phone_num,email_add);
    }
    public String toString(){
        return super.toString();
    }
    public void VendorManagement(){
        System.out.println();
        System.out.println("1. View Vendor List");
        System.out.println("2. Update Vendor List");
        System.out.println("3. Delete Vendor From List");
        System.out.println("4. Back to Admin Menu");
        System.out.println("Enter your input : ");
        int opt = scanInt.nextInt();
        if(opt == 1){
            System.out.println("====================== LIST OF VENDORS =====================");
            for (int i = 0; i < vendors.size(); i++) {
                System.out.println(vendors.get(i).toString());
            }
        }else if(opt == 2){
            System.out.println("===================== UPDATE VENDOR LIST ===================");
            System.out.println("Please input the User ID you want to update : ");
            String user_id = scanStr.nextLine();

        }else if(opt == 3){
            System.out.println("======================= DELETE VENDOR ======================");
        }else if(opt == 4){
            System.out.println("Back to admin menu...");
        }
    }
}
